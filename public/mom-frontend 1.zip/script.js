document.addEventListener('DOMContentLoaded', (event) => {

    
    const viewportWidth = window.innerWidth
    const viewportHeight = window.innerHeight
    
    function myFunc() {
        document.getElementById("heading").textContent = "hello world!"
    }
    
    if (window.matchMedia('screen and (max-width: 768px)').matches) {
        document.getElementById('toggler').style.display = 'none'

    }

    function showMobileMenu() {
    
}
})

